// Minimal Service Worker untuk PWA
self.addEventListener('fetch', function(event) {
    // Agar aplikasi bisa berjalan dan diinstal
});